#!/usr/bin/env bash
export CUDA_VISIBLE_DEVICES=2
python main.py
